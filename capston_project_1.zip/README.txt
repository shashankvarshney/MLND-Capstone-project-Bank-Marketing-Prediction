Data set has been acquired from UCI machine learning repository. FOllowing is the link of the same.

https://archive.ics.uci.edu/ml/machine-learning-databases/00222/bank-additional.zip

Following libraries has been used for this project.

Scikit-Learn
Pandas
Numpy
Scipy
pprint
time
matplotlib